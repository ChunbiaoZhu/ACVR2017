%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [ Dis_weight ] = DES_2DDistanceCue( idx, DisVector, para )
%GETPOSITIONW Summary of this function goes here
%   Detailed explanation goes here

Dis_weight=zeros(para.cluster_num,1);

for i=1:para.cluster_num
    x=sum(DisVector(idx==i))/size(DisVector(idx==i),1);
    Dis_weight(i) = exp(-x.^2/(para.img_W^2));
end

end

