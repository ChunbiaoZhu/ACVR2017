%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [ Dep_weight ] = DES_DepDistanceCue( Depth_vector, idx, para)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

DOF = max(Depth_vector)-min(Depth_vector);

meandepth = zeros(para.cluster_num,1);
for i=1:para.cluster_num
    meandepth(i) = sum(Depth_vector(idx==i))/size(find(idx==i),1);
end    
 
Dep_weight = (max(meandepth)-meandepth).^(para.gamma/DOF);%

end

