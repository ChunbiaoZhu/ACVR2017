%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [ datadir ] = FDS_mkdir( datadir )
%MKDIR_FHZ Summary of this function goes here
%   Detailed explanation goes here

    if (~exist(datadir, 'dir'))
        mkdir(datadir);
    end

end

