copyright@zhuchunbiao@pku.edu.cn
cite as:
@inproceedings{zhu2017innovative,
  title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
  author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
  booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
  pages={1509--1515},
  year={2017}
}


How to use:
First, run  run_dark_prior.m
Second, run  run_center_prior.m
Third, run main.m



PKU80 Dataset is public.
You can download in here (https://github.com/ChunbiaoZhu/TPPF).

For more information, you can visit: https://chunbiaozhu.github.io/ACVR2017/

If you have any question, please contact me (email, zhuchunbiao@pku.edu.cn)

Thank you!