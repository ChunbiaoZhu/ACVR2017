%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [ norm_vector ] = DES_GaussNorm( vector )
%GAUSS_NORMAL Summary of this function goes here
%   Detailed explanation goes here

% output_args = exp(-(vector-max(vector)).^2/((max(vector)-min(vector)/2)^2));

mean_v = (max(vector)-min(vector))/2;
max_v = max(vector);
norm_vector = exp(-(vector- max_v).^2/(mean_v^2));

% output_args=DES_Get_Gaussmf(vector,[(max(vector)-min(vector))/2 max(vector)]);

end

