%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [ FDS_map ] = DES_GenerateMap( DES_para, DES_Cue)
%FDS_GENERATEMAP Summary of this function goes here
%   Detailed explanation goes here

Saliency_temp= reshape(DES_Cue.ClusterIdx, DES_para.img_H, DES_para.img_W);
for j=1:DES_para.cluster_num
    Saliency_temp(Saliency_temp==j)=DES_Cue.FinalCue(j);
end
FDS_map = imfilter(Saliency_temp, fspecial('gaussian', [3, 3], 3));


end

