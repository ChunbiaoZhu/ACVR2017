%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function weights=makeweights(edges,vals,valScale)
valDistances=sqrt(sum((vals(edges(:,1),:)-vals(edges(:,2),:)).^2,2));
valDistances=normalize(valDistances); %Normalize to [0,1]
weights=exp(-valScale*valDistances);
