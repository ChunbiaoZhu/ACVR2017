%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function matrix = normalization(mat, flag)
% INPUT : 
%         flag:  1 denotes that the mat is a cell;
%                0 denotes that the mat is a matrix;
%         
if flag ~= 0
    dim = length(mat);
    for i = 1:dim
       matrix{i} = ( mat{i} - min(min(mat{i}))) / ( max(max(mat{i})) - min(min( mat{i})));
    end
else
    matrix = ( mat - min(min(mat)))/( max(max(mat)) - min(min(mat)));
end