%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }

close all;
clear all;

imgRoot='./Image/';
imnames=dir([imgRoot '*' 'png']);

for ii=1:length(imnames);
    ii
    imname=[imgRoot imnames(ii).name]; 
    t_r=double(imread(imname));
    global_light = quadTree_A( t_r,2);

    %calculate t
    t_r = transmissionEstimate( t_r,global_light);
    A =t_r;
    Result_path = ('./dark_results/');
    imwrite(A, [Result_path imnames(ii).name(1:end-4) '_dark.png'], 'png');
end