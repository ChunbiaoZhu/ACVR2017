%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }

function JDark = darkChannel(im2)

[height, width, ~] = size(im2);
patchSize = 15; %the patch size is set to be 15 x 15
padSize = floor(patchSize/2); % half the patch size to pad the image with for the array to 
JDark = zeros(height, width); % the dark channel
imJ = padarray(im2, [padSize padSize], Inf); % the new image

for j = 1:height
    for i = 1:width
        patch = imJ(j:(j+patchSize-1), i:(i+patchSize-1),:); 
        JDark(j,i) = min(patch(:));
     end
end
