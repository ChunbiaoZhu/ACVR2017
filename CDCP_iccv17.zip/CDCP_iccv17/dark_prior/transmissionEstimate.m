%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function transmission = transmissionEstimate(im, A)

omega = 0.95; % the amount of haze we're keeping
im3=zeros(size(im));
for ind=1:3
    im3(:,:,ind) = im(:,:,ind)./A(ind);
end
% imagesc(im3./(max(max(max(im3))))); colormap gray; axis off image

transmission = 1-omega*darkChannel(im3);
