%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
function [A] = quadTree_A(img,winSize)
    [H,W,~]=size(img);
    if H<winSize || W<winSize;
         A=findA(img);
    else
       s1=score(img(1:int32(H/2),1:int32(W/2),:));
       s2=score(img(1:int32(H/2),int32(W/2)+1:end,:));
       s3=score(img(int32(H/2)+1:end,1:int32(W/2),:)); 
       s4=score(img(int32(H/2)+1:end,int32(W/2)+1:end,:));
       smax=max([s1 s2 s3 s4]);
       switch smax
           case s1
               A=quadTree_A(img(1:int32(H/2),1:int32(W/2),:),winSize);
           case s2
               A=quadTree_A(img(1:int32(H/2),int32(W/2)+1:end,:),winSize);
           case s3
               A=quadTree_A(img(int32(H/2)+1:end,1:int32(W/2),:),winSize);
           case s4
               A=quadTree_A(img(int32(H/2)+1:end,int32(W/2)+1:end,:),winSize);
       end
    end
    
    function [s]=score(patch)
        patch1d=reshape(patch,size(patch,1)*size(patch,2),3);
        pstd=std(patch1d(:),1);
        pmean=mean(patch1d(:),1);
        s=sum(abs(pmean-pstd));
    end
    
    function A=findA(patch)
        [heigth,width,~]=size(patch);
        A=ones(1,3);
        for k=1:3
            A(k)=sum(sum(patch(:,:,k)))/(heigth*width);
        end
    end
end