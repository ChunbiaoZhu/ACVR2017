%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @inproceedings{zhu2017innovative,
%   title={An Innovative Salient Object Detection Using Center-Dark Channel Prior},
%   author={Zhu, Chunbiao and Li, Ge and Wang, Wenmin and Wang, Ronggang},
%   booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
%   pages={1509--1515},
%   year={2017}
% }
close all;
clear all;
imgRoot='./Input/Image/';
imnames=dir([imgRoot '*' 'png']);
centerRoot='./center_prior/center_results/';%% center-bias image dir
centernames=dir([centerRoot '*' 'png']);

for ii=1:length(imnames);
    disp(ii)
    imname=[imgRoot imnames(ii).name]; 
    RGB_img=imread(imname); 
    centername=[centerRoot centernames(ii).name]; 
    RGB_imgCenter=im2double(imread(centername)); 
    % image set path
    img_name = imname;
    % RGB_path= input_im;
    Depth_path= ['./Input/depth/' imnames(ii).name(1:end-4) '_depth.png'];

    Dark_path= ['./dark_prior/dark_results/' imnames(ii).name(1:end-4) '_dark.png'];

    Result_path = FDS_mkdir('./Output/');

    % parameters
    DES_para.cluster_num= 40; %clustering number 
    DES_para.sigma2 = 0.4;
    DES_para.gamma = 1;

    depth_map  = im2double(imread(Depth_path));
    dark_map = im2double(imread(Dark_path));

    [DES_para.img_H, DES_para.img_W, DES_para.img_C] = size(RGB_img); 
    DES_para.img_vector_size = DES_para.img_H* DES_para.img_W; 
    RGB_img = mat2gray(RGB_img);
    DES_Cue = DES_SaliencyCue( RGB_img, depth_map, DES_para );
    DES_Cue.FinalCue = DES_GaussNorm((DES_Cue.Contrast2D.*DES_Cue.Distance2D));

    % generate saliency map  
    Saliency_map = DES_GenerateMap(DES_para, DES_Cue);

    Final_saliency =dark_map.*Saliency_map.*RGB_imgCenter.*10;
    imwrite(Final_saliency, [Result_path imnames(ii).name(1:end-4) '_final.png'], 'png');
end